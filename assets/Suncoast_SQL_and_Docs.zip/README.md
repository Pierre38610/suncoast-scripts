# Suncoast Scripts — Next-Gen FiveM Crime & Vehicle Mechanics Suite

Complete, server-authoritative 4-resource FiveM suite built with **Lua 5.4**, **React + TypeScript NUI**, **Cfx.re Asset Escrow** manifests, and an unlocked **Open Multi-Framework Bridge** (`QBox`, `QBCore`, `ESX`, `Standalone`).

## Resources Included
1. `resources/sc_vehscan` — **PrismScan**: Optical AR vehicle scanner, security tier/powertrain detector, damage-adjusted fence appraisal, 200-vehicle discovery registry (`/vehcatalog`), and 18 Exotic Hot-List targets (`+45%`).
2. `resources/sc_carjack` — **ShiftLock**: 3-tier theft progression (`slim_jim`, `bypass_kit`, `key_cloner`), PrismScan tolerance synergy, single-use nonce + min-duration anti-cheat, live police GPS tracker pings, and `/disarmgps` jammer minigame.
3. `resources/sc_launder` — **VaultNet**: Encrypted shared crew accounts (`/vaultnet` & ATMs) with daily withdrawal caps, 35% death / 100% arrest loose cash risk, visual duffel cargo, and 4 heat-reactive fence channels.
4. `resources/sc_wanted` — **HeatHUD**: 6-star Solid & Hollow evasion overlay, `1.75x` outfit/vehicle scramble and `3.0x` dual-scramble cooldown multipliers, police BOLO alerts, and persistent `/infamy` dossier.

## Development & Verification Commands

```bash
npm install
npm run build:nui        # Compiles all 4 React NUIs (./assets/ relative paths) + Showcase
npm run typecheck        # Strict TypeScript check
npm run test             # Vitest: Manifest/Escrow + IP Compliance + Lua 5.4 Runtime Tests
npm run test:e2e         # Playwright E2E across all 4 interactive NUIs
npm run generate:assets  # Captures 5x 1920x1080 PNG previews + interactive .webm walkthrough
npm run package:tebex    # Packages POSIX-compliant .zip archives in dist/tebex/
npm run verify:all       # Full end-to-end build, test, and package pipeline
```

## Key Project Files
- [`00_recherche_approfondie_gemini_gta6.md`](00_recherche_approfondie_gemini_gta6.md) — Full extracted Gemini Deep Research report (all 10 ideas).
- [`GUIDE_MONETISATION_FIVEM_TEBEX.md`](GUIDE_MONETISATION_FIVEM_TEBEX.md) — End-to-end monetization & AI vs Human execution roadmap + Antigravity model guide.
- [`storefront/TEBEX_PACKAGES_COPY.md`](storefront/TEBEX_PACKAGES_COPY.md) — Storefront & 5 Tebex product descriptions.
- [`storefront/CFX_FORUM_RELEASES.md`](storefront/CFX_FORUM_RELEASES.md) — 4 compliant `forum.cfx.re/c/releases` posts (48h staggered).
- [`storefront/DISCORD_BOT_AND_SERVER_SETUP.md`](storefront/DISCORD_BOT_AND_SERVER_SETUP.md) — Discord support architecture & Tebex role bot guide.
- [`docs/RESMON_AND_TESTING_CHECKLIST.md`](docs/RESMON_AND_TESTING_CHECKLIST.md) — 5-minute FXServer `resmon 1` + 60s gameplay capture checklist (+ Fiverr brief).
