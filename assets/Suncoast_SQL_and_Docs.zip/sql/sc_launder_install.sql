CREATE TABLE IF NOT EXISTS `sc_vault_accounts` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `account_code` VARCHAR(24) NOT NULL,
  `name` VARCHAR(64) NOT NULL,
  `owner_identifier` VARCHAR(80) NOT NULL,
  `balance` BIGINT NOT NULL DEFAULT 0,
  `daily_withdraw_limit` INT NOT NULL DEFAULT 50000,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_account_code` (`account_code`),
  INDEX `idx_owner` (`owner_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sc_vault_members` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `account_code` VARCHAR(24) NOT NULL,
  `identifier` VARCHAR(80) NOT NULL,
  `display_name` VARCHAR(80) NOT NULL,
  `role` VARCHAR(24) NOT NULL DEFAULT 'member',
  `withdrawn_today` INT NOT NULL DEFAULT 0,
  `last_reset_day` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_account_member` (`account_code`, `identifier`),
  INDEX `idx_member_ident` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sc_vault_transactions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `account_code` VARCHAR(24) NOT NULL,
  `actor_identifier` VARCHAR(80) NOT NULL,
  `actor_name` VARCHAR(80) NOT NULL,
  `tx_type` VARCHAR(24) NOT NULL,
  `amount` INT NOT NULL,
  `note` VARCHAR(160) NOT NULL DEFAULT '',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_tx_account` (`account_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sc_fence_stats` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(80) NOT NULL,
  `channel` VARCHAR(32) NOT NULL,
  `total_moved` BIGINT NOT NULL DEFAULT 0,
  `deals_count` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ident_channel` (`identifier`, `channel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sc_duffel_inventories` (
  `identifier` VARCHAR(80) NOT NULL,
  `items_json` LONGTEXT NOT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
