CREATE TABLE IF NOT EXISTS `sc_vehscan_records` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(80) NOT NULL,
  `model` VARCHAR(64) NOT NULL,
  `label` VARCHAR(120) NOT NULL,
  `class_name` VARCHAR(48) NOT NULL,
  `security_tier` TINYINT NOT NULL DEFAULT 1,
  `powertrain` VARCHAR(16) NOT NULL DEFAULT 'ICE',
  `exotic` TINYINT(1) NOT NULL DEFAULT 0,
  `best_value` INT NOT NULL DEFAULT 0,
  `scan_count` INT NOT NULL DEFAULT 1,
  `first_scanned_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_scanned_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_player_model` (`identifier`, `model`),
  INDEX `idx_identifier` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
