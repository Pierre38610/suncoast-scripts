# FXServer `resmon 1` Verification & 60s Gameplay Capture Checklist

Because Cfx.re buyers on `forum.cfx.re` strongly expect a real in-game FiveM gameplay clip showing **`resmon 1` idle/active CPU usage** (`0.00ms - 0.02ms`), completing one short 60-second capture before publishing your forum posts dramatically boosts conversion rates.

---

## Option A — Do It Yourself Locally (~10 minutes if GTA V is installed)
1. Download the latest Windows **FXServer artifacts** from `runtime.fivem.net/artifacts/fivem/build_server_windows/master/`.
2. Unzip into `C:\FXServer`, drop our 4 folders from `resources/` into `server-data/resources/[suncoast]/`, plus `oxmysql` if testing persistence.
3. Add to `server.cfg`:
   ```cfg
   ensure sc_vehscan
   ensure sc_wanted
   ensure sc_launder
   ensure sc_carjack
   ```
4. Launch FXServer + FiveM client, press **F8**, and run `resmon 1`.
5. Record a crisp 60–75 second 1080p clip (OBS or Windows Game Bar `Win+G`) demonstrating:
   - **0:00–0:15:** Idle `resmon 1` showing `0.00ms` on all 4 `sc_*` scripts -> press `Y` (`/vehscan`), scan an Exotic car (`Pegassi Ignus`) -> NUI lock-on + `/vehcatalog`.
   - **0:15–0:32:** Approach locked exotic car -> ShiftLock Tier 3 Rolling-Code Signal Cloner -> keys spoofed -> `/disarmgps` Jammer minigame.
   - **0:32–0:48:** HeatHUD top-right Solid 4-star -> step out of sight -> Hollow Stars + swap outfit/vehicle (`3.0x` multiplier) + `/infamy` drawer.
   - **0:48–1:05:** Open `/vaultnet` ATM -> deposit cash, check Crew Ledger, switch to 4-Channel Fences tab, sell duffel cargo.
6. Upload as **Unlisted YouTube** or **Streamable** and paste the link into Tebex & `CFX_FORUM_RELEASES.md`.

---

## Option B — Zero-Setup Outsource on Fiverr (~15–25 €, 2 min human time)
If you do not have GTA V / FiveM installed on your PC, hire any FiveM test-server freelancer on Fiverr with this exact brief:

> **Title:** Record a 60–75s 1080p showcase video + `resmon 1` overlay of 4 FiveM scripts on your local QBCore/ESX test server
>
> **Deliverable:** One clean 1080p 60fps MP4 showing:
> 1. Opening `resmon 1` in F8 to confirm `0.00ms–0.01ms` idle across `sc_vehscan`, `sc_carjack`, `sc_launder`, `sc_wanted`.
> 2. Using `/vehscan` (aiming at 1 standard car + 1 supercar) + `/vehcatalog`.
> 3. Using ShiftLock minigame to steal a locked car + `/disarmgps`.
> 4. Triggering `/setheat 1 500`, breaking sight into Hollow Stars, changing clothes/car, and opening `/infamy`.
> 5. Opening `/vaultnet`, depositing cash, and fencing loot at a Fence NPC.
>
> Provide the 4 unzipped standalone folders (or Escrow grant to your Cfx ID) + step-by-step timestamp checklist. Keep video raw without copyrighted music.
